import numpy as np
import sys
sys.path.append('..')
from utils import label_to_onehot


class LogisticRegression(object):
    """
        LogisticRegression classifier object.
        Feel free to add more functions to this class if you need.
        But make sure that __init__, set_arguments, fit and predict work correctly.
    """

    def __init__(self, *args, **kwargs):
        """
            Initialize the task_kind (see dummy_methods.py)
            and call set_arguments function of this class.
        """
        
        ##
        ###
        #### YOUR CODE HERE! 
        ###
        ##
        self.task_kind = 'classification'
        self.set_arguments(*args, **kwargs)

    def set_arguments(self, *args, **kwargs):
        """
            args and kwargs are super easy to use! See dummy_methods.py
            The LogisticRegression class should have variables defining the learning rate (lr)
            and the number of max iterations (max_iters)
            You can either pass these as args or kwargs.
        """
        
        ##
        ###
        #### YOUR CODE HERE! 
        ###
        ##
        if 'lr' in kwargs:
            self.lr = kwargs['lr']
        elif len(args) > 0 :
            self.lr = args[0]
        if 'max_iters' in kwargs:
            self.max_iters = kwargs['max_iters']
        elif len(args) > 0 :
            self.max_iters = args[1]
            
       

    def fit(self, training_data, training_labels):
        """
            Trains the model, returns predicted labels for training data.
            Arguments:
                training_data (np.array): training data of shape (N,D)
                training_labels (np.array): regression target of shape (N,regression_target_size)
            Returns:
                pred_labels (np.array): target of shape (N,regression_target_size)
        """
        
        
        ##
        ###
        #### YOUR CODE HERE! 
        ###
        ##
        def f_softmax(X,w):
            
            res = np.empty([X.shape[0], w.shape[1]])
            s = np.sum(np.exp(X@w), axis = 1)
            for col in range(w.shape[1]):
                proba = np.exp(X@w[:, col])
                res[:, k] = proba/s
            return res
        
        def gradient_logistic(X,y,w):
            grad = np.zeros(w.shape)
            res = f_softmax(X, w)
            for k in range(w.shape[1]):
                grad[:, k] = X.T@(res[:,k]-(y==k))

            return grad
        
        def logistic_regression_classify(X,w):
            
            predictions = 1*np.array(np.argmax(f_softmax(X,w),axis = 1))
            return predictions
        
        def logistic_regression_train(X,y):
            w = np.random.normal(0.,0.1,[X.shape[1],y.size])
            
            for it in range(self.max_iters):
                w = w - self.lr * gradient_logistic(X,y,w)
            return w 
        
        self.w = logistic_regression_train(training_data,training_labels)
        pred_labels = logistic_regression_classify(training_data, self.w)
        return pred_labels

    def predict(self, test_data):
        """
            Runs prediction on the test data.s
            
            Arguments:
                test_data (np.array): test data of shape (N,D)
            Returns:
                test_labels (np.array): labels of shape (N,)
        """   
        ##
        ###
        #### YOUR CODE HERE! 
        ###
        ##
        
        def f_softmax(X,w):
            res = np.empty([X.shape[0], w.shape[1]])
            s = np.sum(np.exp(X@w), axis = 1)
            for col in range(w.shape[1]):
                proba = np.exp(X@w[:, col])
                res[:, k] = proba/s
            return res
        
        def logistic_regression_classify(X,w):
            
            predictions = 1*np.array(np.argmax(f_softmax(X,w),axis = 1))
            return predictions
        
        pred_labels = logistic_regression_classify(test_data,self.w)
        return pred_labels